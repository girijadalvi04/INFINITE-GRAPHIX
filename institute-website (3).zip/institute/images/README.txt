Replace any picture by saving your own file with the SAME name in the same folder.
If your file has another extension (.jpg/.png), also change the name inside data.js.
images/placements-home/ and images/placement-cards/ : add your placement photos here (kept as placeholders).
All other folders contain illustration placeholders named after the course/section.
